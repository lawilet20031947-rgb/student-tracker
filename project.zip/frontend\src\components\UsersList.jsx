import React, { useEffect, useState } from "react";
import { functions } from "../firebase";
import { httpsCallable } from "firebase/functions";

export default function UsersList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [changing, setChanging] = useState(null);

  useEffect(() => {
    let mounted = true;
    async function fetchUsers() {
      setLoading(true);
      try {
        const fn = httpsCallable(functions, "listUsers");
        const res = await fn();
        if (mounted) {
          setUsers(res.data.users || []);
        }
      } catch (err) {
        console.error("listUsers error", err);
        setUsers([]);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    fetchUsers();
    return () => (mounted = false);
  }, []);

  async function changeRole(uid, newRole) {
    setChanging(uid);
    try {
      const fn = httpsCallable(functions, "setUserRole");
      await fn({ uid, role: newRole });
      setUsers((prev) => prev.map(u => u.uid === uid ? { ...u, role: newRole } : u));
    } catch (err) {
      console.error("setUserRole error", err);
      alert(err.message || "Failed to update role");
    } finally {
      setChanging(null);
    }
  }

  if (loading) return <div>Loading users…</div>;
  if (!users.length) return <div>No users found.</div>;

  return (
    <div className="space-y-2">
      {users.map((u) => (
        <div key={u.uid} className="p-3 border rounded flex items-center justify-between">
          <div>
            <div className="font-medium">{u.displayName || "(no name)"}</div>
            <div className="text-sm text-gray-600">{u.email || u.uid}</div>
            <div className="text-xs text-gray-500">uid: {u.uid}</div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={u.role || "student"}
              onChange={(e) => changeRole(u.uid, e.target.value)}
              disabled={changing === u.uid}
              className="border px-2 py-1 rounded"
            >
              <option value="student">student</option>
              <option value="teacher">teacher</option>
              <option value="admin">admin</option>
            </select>
            {changing === u.uid ? <div className="text-sm">Saving…</div> : null}
          </div>
        </div>
      ))}
    </div>
  );
}
