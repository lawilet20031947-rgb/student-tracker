import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function ProtectedRoute({ children, role }) {
  const { user, loading, role: userRole } = useAuth();

  if (loading) return <div>Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;

  // If route requires a role, check it (allow admin all routes)
  if (role && userRole !== role) {
    if (userRole !== "admin") {
      return <Navigate to="/login" replace />;
    }
  }

  return children;
}
