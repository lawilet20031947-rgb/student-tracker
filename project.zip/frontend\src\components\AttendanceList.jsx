import React, { useEffect, useState } from "react";
import { collection, query, where, orderBy, onSnapshot, doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

export default function AttendanceList({ studentId }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userMap, setUserMap] = useState({}); // uid -> user doc

  useEffect(() => {
    if (!db) {
      setItems([]);
      setLoading(false);
      return;
    }
    let q;
    const col = collection(db, "attendance");
    if (studentId) {
      q = query(col, where("studentId", "==", studentId), orderBy("createdAt", "desc"));
    } else {
      q = query(col, orderBy("createdAt", "desc"));
    }
    const unsub = onSnapshot(q, async (snap) => {
      const fetched = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setItems(fetched);
      // Prefetch user docs for all unique studentIds in attendance records
      const uids = [...new Set(fetched.map(it => it.studentId))];
      const map = {};
      await Promise.all(uids.map(async (uid) => {
        try {
          const userSnap = await getDoc(doc(db, "users", uid));
          map[uid] = userSnap.exists() ? userSnap.data() : null;
        } catch {
          map[uid] = null;
        }
      }));
      setUserMap(map);
      setLoading(false);
    }, (err) => {
      console.error('Attendance onSnapshot error', err);
      setLoading(false);
    });
    return () => unsub();
  }, [studentId]);

  if (loading) return <div className="text-sm text-gray-500">Loading attendance...</div>;
  if (!items.length) return <div className="text-sm text-gray-500">No attendance records.</div>;

  return (
    <ul className="space-y-2">
      {items.map(it => {
        const user = userMap[it.studentId];
        return (
          <li key={it.id} className="p-2 border rounded">
            <div className="text-sm font-bold">
              {user ? (
                <>
                  {user.displayName || user.email} <span className="text-xs text-gray-500">({it.studentId})</span>
                </>
              ) : (
                <>UID: {it.studentId}</>
              )}
            </div>
            <div className="text-sm">Date: {it.date}</div>
            <div className="text-sm">Status: {it.status}</div>
          </li>
        );
      })}
    </ul>
  );
}
