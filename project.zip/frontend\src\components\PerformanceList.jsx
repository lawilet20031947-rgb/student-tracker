import React, { useEffect, useState } from "react";
import { collection, query, where, orderBy, onSnapshot, doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

export default function PerformanceList({ studentId }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userMap, setUserMap] = useState({}); // uid -> user info

  useEffect(() => {
    if (!db) {
      setItems([]);
      setLoading(false);
      return;
    }
    const col = collection(db, "performance");
    const q = studentId
      ? query(col, where("studentId", "==", studentId), orderBy("createdAt", "desc"))
      : query(col, orderBy("createdAt", "desc"));

    const unsub = onSnapshot(q, async (snap) => {
      const fetched = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setItems(fetched);
      // Prefetch user docs for all unique studentIds
      const uids = [...new Set(fetched.map(it => it.studentId))];
      const map = {};
      await Promise.all(uids.map(async (uid) => {
        try {
          const userSnap = await getDoc(doc(db, "users", uid));
          map[uid] = userSnap.exists() ? userSnap.data() : null;
        } catch {
          map[uid] = null;
        }
      }));
      setUserMap(map);
      setLoading(false);
    }, (err) => {
      console.error('Performance onSnapshot error', err);
      setLoading(false);
    });
    return () => unsub();
  }, [studentId]);

  if (loading) return <div className="text-sm text-gray-500">Loading performance...</div>;
  if (!items.length) return <div className="text-sm text-gray-500">No performance records.</div>;

  return (
    <ul className="space-y-2">
      {items.map(it => {
        const user = userMap[it.studentId];
        return (
          <li key={it.id} className="p-2 border rounded">
            <div className="text-sm font-bold">
              {user ? (
                <>
                  {user.displayName || user.email} <span className="text-xs text-gray-500">({it.studentId})</span>
                </>
              ) : (
                <>UID: {it.studentId}</>
              )}
            </div>
            <div className="text-sm">Subject: {it.subject}</div>
            <div className="text-sm">Marks: {it.marks}</div>
            <div className="text-sm">Date: {it.date}</div>
          </li>
        );
      })}
    </ul>
  );
}
